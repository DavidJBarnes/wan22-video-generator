import { useState } from 'react';
import { Button, TextField, Rating, Box, Typography } from '@mui/material';
import API from '../api/client';
import { showToast } from '../utils/helpers';
import './CreateJobModal.css';

// Clean up base_name by removing {TYPE} placeholder
function cleanBaseName(baseName) {
  if (!baseName) return '';
  return baseName.replace(/\{type\}/gi, '').replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim();
}

export default function LoraEditModal({ lora, onClose, onSave }) {
  const [friendlyName, setFriendlyName] = useState(lora.friendly_name || '');
  const [url, setUrl] = useState(lora.url || '');
  const [promptText, setPromptText] = useState(lora.prompt_text || '');
  const [triggerKeywords, setTriggerKeywords] = useState(lora.trigger_keywords || '');
  const [rating, setRating] = useState(lora.rating || null);
  const [notes, setNotes] = useState(lora.notes || '');
  const [defaultHighWeight, setDefaultHighWeight] = useState(lora.default_high_weight ?? 1.0);
  const [defaultLowWeight, setDefaultLowWeight] = useState(lora.default_low_weight ?? 1.0);
  const [previewCacheBust, setPreviewCacheBust] = useState(Date.now());
  const [previewError, setPreviewError] = useState(false);
  const [saving, setSaving] = useState(false);
  const [fetchingPreview, setFetchingPreview] = useState(false);

  // Always try to load the preview URL - let onError handle missing previews
  const previewUrl = `${API.getLoraPreviewUrl(lora.id)}?t=${previewCacheBust}`;

  async function handleFetchPreview() {
    if (!url || !url.includes('civitai.com')) {
      showToast('Enter a CivitAI URL first', 'warning');
      return;
    }

    setFetchingPreview(true);
    try {
      await API.refreshLoraPreview(lora.id);
      setPreviewError(false);
      setPreviewCacheBust(Date.now()); // Force refresh the cached image
      showToast('Preview fetched and cached', 'success');
    } catch (error) {
      console.error('Failed to fetch preview:', error);
      showToast('Failed to fetch preview from CivitAI', 'error');
    } finally {
      setFetchingPreview(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);

    try {
      await API.updateLora(lora.id, {
        friendly_name: friendlyName || null,
        url: url || null,
        prompt_text: promptText || null,
        trigger_keywords: triggerKeywords || null,
        rating: rating,
        notes: notes || null,
        default_high_weight: defaultHighWeight,
        default_low_weight: defaultLowWeight
        // preview_image_url is managed by the refresh-preview endpoint
      });

      showToast('LoRA metadata updated', 'success');
      setSaving(false);
      onSave();
    } catch (error) {
      console.error('Failed to update LoRA:', error);
      showToast('Failed to update LoRA metadata', 'error');
      setSaving(false);
    }
  }

  return (
    <div className="modal-overlay">
      <form className="modal-content" onSubmit={handleSubmit}>
        {/* Header */}
        <div className="modal-header">
          <h2>Edit LoRA: {cleanBaseName(lora.base_name)}</h2>
          <button type="button" className="modal-close" onClick={onClose}>×</button>
        </div>

        {/* Body */}
        <div className="modal-body">
          <div style={{ marginBottom: '16px', padding: '12px', background: '#f5f5f5', borderRadius: '4px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', fontSize: '12px' }}>
              <div>
                <span style={{ color: '#2e7d32', fontWeight: 500 }}>HIGH:</span>{' '}
                <code>{lora.high_file ? lora.high_file.split('/').pop() : '—'}</code>
              </div>
              <div>
                <span style={{ color: '#1565c0', fontWeight: 500 }}>LOW:</span>{' '}
                <code>{lora.low_file ? lora.low_file.split('/').pop() : '—'}</code>
              </div>
            </div>
            <div style={{ display: 'flex', gap: '12px', marginTop: '12px', paddingTop: '12px', borderTop: '1px solid #ddd' }}>
              <TextField
                type="number"
                label="Default High Weight"
                size="small"
                value={defaultHighWeight}
                onChange={(e) => setDefaultHighWeight(parseFloat(e.target.value) || 0)}
                inputProps={{ min: 0, max: 2, step: 0.1 }}
                sx={{ width: '140px' }}
              />
              <TextField
                type="number"
                label="Default Low Weight"
                size="small"
                value={defaultLowWeight}
                onChange={(e) => setDefaultLowWeight(parseFloat(e.target.value) || 0)}
                inputProps={{ min: 0, max: 2, step: 0.1 }}
                sx={{ width: '140px' }}
              />
            </div>
            <Typography variant="caption" display="block" sx={{ mt: 1, color: '#666' }}>
              Default weights to populate when this LoRA is selected in Create Job
            </Typography>
          </div>

          <div className="form-group">
            <TextField
              label="Friendly Name"
              value={friendlyName}
              onChange={(e) => setFriendlyName(e.target.value)}
              placeholder="e.g., Realistic Portrait LoRA"
              fullWidth
              variant="outlined"
              size="small"
              helperText="A more readable name to display instead of the technical filename"
            />
          </div>

          <div className="form-group">
            <Box>
              <Typography component="legend" sx={{ fontSize: '14px', mb: 1, color: '#666' }}>
                Rating
              </Typography>
              <Rating
                value={rating}
                onChange={(event, newValue) => {
                  setRating(newValue);
                }}
                size="large"
              />
              <Typography variant="caption" display="block" sx={{ mt: 0.5, color: '#666' }}>
                Rate this LoRA for your own reference
              </Typography>
            </Box>
          </div>

          <div className="form-group">
            <TextField
              label="URL"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://civitai.com/models/..."
              fullWidth
              variant="outlined"
              size="small"
              helperText="Link to the LoRA's page (CivitAI, HuggingFace, etc.)"
            />
          </div>

          {/* Preview Image Section */}
          <div className="form-group">
            <Typography component="legend" sx={{ fontSize: '14px', mb: 1, color: '#666' }}>
              Preview Image
            </Typography>
            <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
              <div style={{
                width: '100px',
                height: '100px',
                backgroundColor: '#f0f0f0',
                borderRadius: '4px',
                overflow: 'hidden',
                flexShrink: 0
              }}>
                <img
                  src={previewUrl}
                  alt="Preview"
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                    display: previewError ? 'none' : 'block'
                  }}
                  onLoad={() => setPreviewError(false)}
                  onError={() => setPreviewError(true)}
                />
                <div style={{
                  width: '100%',
                  height: '100%',
                  display: previewError ? 'flex' : 'none',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#999',
                  fontSize: '11px',
                  textAlign: 'center',
                  padding: '8px'
                }}>
                  No preview
                </div>
              </div>
              <div style={{ flex: 1 }}>
                <Button
                  variant="outlined"
                  size="small"
                  onClick={handleFetchPreview}
                  disabled={fetchingPreview || !url?.includes('civitai.com')}
                  sx={{ mb: 1 }}
                >
                  {fetchingPreview ? 'Fetching...' : 'Fetch from CivitAI'}
                </Button>
                <Typography variant="caption" display="block" sx={{ color: '#666' }}>
                  Automatically fetch preview image from CivitAI URL
                </Typography>
              </div>
            </div>
          </div>

          <div className="form-group">
            <TextField
              label="Trigger Keywords"
              value={triggerKeywords}
              onChange={(e) => setTriggerKeywords(e.target.value)}
              placeholder="e.g., anime style, detailed, high quality"
              fullWidth
              variant="outlined"
              size="small"
              helperText="Keywords that activate this LoRA's style"
            />
          </div>

          <div className="form-group">
            <TextField
              label="Prompt Description"
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              multiline
              minRows={1}
              maxRows={4}
              placeholder="Describe what this LoRA does and how to use it..."
              fullWidth
              variant="outlined"
              size="small"
              helperText="Optional notes about the LoRA's effect and usage"
            />
          </div>

          <div className="form-group">
            <TextField
              label="Notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              multiline
              minRows={1}
              maxRows={4}
              placeholder="Personal notes about this LoRA's performance, good settings, tips..."
              fullWidth
              variant="outlined"
              size="small"
              helperText="Keep track of what works well with this LoRA"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="modal-footer">
          <Button
            type="submit"
            variant="contained"
            disabled={saving}
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </form>
    </div>
  );
}
