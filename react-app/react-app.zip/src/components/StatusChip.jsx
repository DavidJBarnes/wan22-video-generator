import { Chip } from '@mui/material';

const STATUS_CONFIG = {
  pending: { color: 'default', label: 'Pending' },
  running: { color: 'primary', label: 'Running' },
  awaiting_prompt: { color: 'warning', label: 'Awaiting Prompt' },
  completed: { color: 'success', label: 'Completed' },
  failed: { color: 'error', label: 'Failed' },
  paused: { color: 'secondary', label: 'Paused' },
  deleted: { color: 'error', label: 'Deleted' },
};

export default function StatusChip({ status, queuePosition }) {
  const config = STATUS_CONFIG[status] || { color: 'default', label: status };

  // Combine pending status with queue position
  let label = config.label;
  if (status === 'pending' && queuePosition) {
    label = `Pending - #${queuePosition}`;
  }

  return (
    <Chip
      label={label}
      color={config.color}
      size="small"
      sx={{ fontWeight: 500 }}
    />
  );
}
